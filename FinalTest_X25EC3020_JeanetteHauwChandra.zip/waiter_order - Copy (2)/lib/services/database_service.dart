import 'package:supabase_flutter/supabase_flutter.dart';


class DatabaseService {
  final _supabase = Supabase.instance.client;

  Future<List<Map<String, dynamic>>> getMenuItems() async => await _supabase.from('menu_items').select().order('name');
  Future<void> addMenuItem(Map<String, dynamic> item) async => await _supabase.from('menu_items').insert(item);
  Future<void> updateMenuItem(int id, Map<String, dynamic> updates) async => await _supabase.from('menu_items').update(updates).eq('id', id);
  Future<void> deleteMenuItem(int id) async => await _supabase.from('menu_items').delete().eq('id', id);

  Future<int> createOrder(String tableNo, double total) async {
    final res = await _supabase.from('orders').insert({'table_no': tableNo, 'total': total, 'status': 'Pending'}).select().single();
    return res['id'];
  }
  Future<void> addOrderItems(List<Map<String, dynamic>> items) async => await _supabase.from('order_items').insert(items);
  Future<List<Map<String, dynamic>>> getOrdersByStatus(String status) async => await _supabase.from('orders').select().eq('status', status);
  Future<void> updateOrderStatus(int id, String status) async => await _supabase.from('orders').update({'status': status}).eq('id', id);
  Future<void> deleteOrder(int id) async => await _supabase.from('orders').delete().eq('id', id);
}