import 'package:supabase_flutter/supabase_flutter.dart';

class MenuService {
  final _supabase = Supabase.instance.client;

  Future<List<Map<String, dynamic>>> fetchMenu() async {
    return await _supabase.from('menu').select().order('name');
  }

  Future<void> updateMenuItem(String id, Map<String, dynamic> data) async {
    await _supabase.from('menu').update(data).eq('id', id);
  }

  Future<void> deleteMenuItem(String id) async {
    await _supabase.from('menu').delete().eq('id', id);
  }

  Future<void> addMenuItem(Map<String, dynamic> data) async {
    await _supabase.from('menu').insert(data);
  }
}