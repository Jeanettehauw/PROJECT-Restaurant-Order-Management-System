import 'package:supabase_flutter/supabase_flutter.dart';
import '../model/order.dart';

class OrderService {
  final _supabase = Supabase.instance.client;

  Future<List<Order>> fetchOrders({int limit = 100}) async {
    try {
      final response = await _supabase
          .from('orders')
          .select('*')
          .order('created_at', ascending: false)
          .limit(limit);

      final List<dynamic> rawData = response as List<dynamic>;

      return rawData
          .map((json) => Order.fromMap(json as Map<String, dynamic>))
          .toList();
    } catch (e) {
      throw Exception('Failed to load orders: $e');
    }
  }

  Future<List<Map<String, dynamic>>> fetchOrderItems(dynamic orderId) async {
    try {
      return await _supabase
          .from('order_items')
          .select('*')
          .eq('order_id', orderId);
    } catch (e) {
      throw Exception('Failed to load order items: $e');
    }
  }

  Future<void> updateOrderStatus(dynamic orderId, String newStatus) async {
    await _supabase
        .from('orders')
        .update({'status': newStatus})
        .eq('id', orderId)
        .select(); 
  }

  Future<void> deleteOrder(dynamic orderId) async {
    await _supabase.from('order_items').delete().eq('order_id', orderId);
    await _supabase.from('orders').delete().eq('id', orderId);
  }

  Future<void> processPayment(dynamic orderId) async {
    await updateOrderStatus(orderId, 'Paid');
  }
}