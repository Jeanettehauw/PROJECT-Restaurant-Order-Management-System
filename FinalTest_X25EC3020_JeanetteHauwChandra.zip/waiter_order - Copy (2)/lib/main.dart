import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'screens/order_list.dart'; 
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  await Supabase.initialize(
    url: 'https://sltcvcextgxqhdmllasn.supabase.co', 
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNsdGN2Y2V4dGd4cWhkbWxsYXNuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE3ODI3MjUsImV4cCI6MjA5NzM1ODcyNX0.dV_W4wYE8FTBAvZKfDJQiY0lSFuH0oI7E-YyCSZ66u0'
  );
  // print('supabase connection: {$Supabase.}')
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Waiter Order App',
      theme: ThemeData(
        primarySwatch: Colors.blue, 
      ),
      home: const OrderListScreen(), 
    );
  }
}