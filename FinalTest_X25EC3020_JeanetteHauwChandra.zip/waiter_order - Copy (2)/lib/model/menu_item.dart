class MenuItem {
  final int id;
  final String name;
  final double price;
  final String category;
  final bool available;

  MenuItem({
    required this.id, 
    required this.name, 
    required this.price, 
    required this.category, 
    required this.available,
  });

  factory MenuItem.fromMap(Map<String, dynamic> map) {
    return MenuItem(
      id: map['id'] ?? 0,
      name: map['name'] ?? 'Unnamed Item',
      price: (map['price'] as num?)?.toDouble() ?? 0.0,
      category: map['category'] ?? 'Food',
      available: map['available'] ?? true,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'price': price,
      'category': category,
      'available': available,
    };
  }
}