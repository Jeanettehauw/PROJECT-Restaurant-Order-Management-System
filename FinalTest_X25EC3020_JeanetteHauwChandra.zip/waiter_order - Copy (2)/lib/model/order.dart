import 'package:flutter/material.dart';

class Order {
  final int id;
  final String tableNo;
  final String status; // Pending, Preparing, Served, Paid, Cancelled
  final String nameSnapshot;
  final double total;

  Order({
    required this.id,
    required this.tableNo,
    required this.status,
    required this.nameSnapshot,
    required this.total,
  });

  bool get canDelete => status == 'Pending';
  bool get canProcessPayment => status == 'Served';
  bool get isPaid => status == 'Paid';
  bool get isCancelled => status == 'Cancelled';

  Color get statusColor {
    if (isCancelled) return Colors.red.shade700;
    if (status == 'Pending') return Colors.orange.shade800;
    if (status == 'Preparing') return Colors.blue.shade700;
    if (isPaid) return Colors.purple.shade700;
    return Colors.green.shade700; // Served
  }

  Color get backgroundColor {
    if (isCancelled) return Colors.red.shade50;
    if (status == 'Pending') return Colors.orange.shade50;
    if (status == 'Preparing') return Colors.blue.shade50;
    if (isPaid) return Colors.purple.shade50;
    return Colors.green.shade50; // Served
  }

  factory Order.fromMap(Map<String, dynamic> map) {
    return Order(
      id: map['id'] ?? 0,
      tableNo: (map['table_no'] ?? 'Unknown').toString(),
      status: (map['status'] ?? 'Pending').toString(),
      nameSnapshot: (map['name_snapshot'] ?? '').toString(),
      total: (map['total'] != null) ? (map['total'] as num).toDouble() : 0.0,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id, 
      'table_no': tableNo,
      'status': status,
      'name_snapshot': nameSnapshot, 
      'total': total,
    };
  }
}