import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart'; 
import '../model/order.dart';
import '../services/order_service.dart';

class OrderDetailScreen extends StatefulWidget {
  final Order order;
  const OrderDetailScreen({super.key, required this.order});

  @override
  State<OrderDetailScreen> createState() => _OrderDetailScreenState();
}

class _OrderDetailScreenState extends State<OrderDetailScreen> {
  final OrderService _orderService = OrderService();
  Future<List<Map<String, dynamic>>>? _itemsFuture;
  late Order _currentOrder;

  @override
  void initState() {
    super.initState();
    _currentOrder = widget.order;
    _itemsFuture = _orderService.fetchOrderItems(_currentOrder.id);
  }

  Future<void> _handleUpdateStatus(String newStatus) async {
    await _orderService.updateOrderStatus(_currentOrder.id, newStatus);
    setState(() {
      _currentOrder = Order(
        id: _currentOrder.id,
        tableNo: _currentOrder.tableNo,
        status: newStatus,
        nameSnapshot: _currentOrder.nameSnapshot,
        total: _currentOrder.total,
      );
    });
  }

  Future<void> _handleDeleteOrder() async {
    final confirm = await _showConfirmationDialog(
      "Delete Order?", 
      "This action cannot be undone.",
      isDanger: true,
    );
    if (confirm == true) {
      await _orderService.deleteOrder(_currentOrder.id);
      if (mounted) Navigator.pop(context);
    }
  }

  Future<void> _handlePayment() async {
    final confirm = await _showConfirmationDialog(
      "Confirm Payment", 
      "Mark table ${_currentOrder.tableNo} as Paid?",
    );
    if (confirm == true) {
      await _orderService.processPayment(_currentOrder.id);
      _handleUpdateStatus('Paid');
      if (mounted) Navigator.pop(context);
    }
  }

  Future<bool?> _showConfirmationDialog(String title, String content, {bool isDanger = false}) {
    return showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(content),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false), 
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            style: isDanger ? ElevatedButton.styleFrom(backgroundColor: Colors.red) : null,
            onPressed: () => Navigator.pop(ctx, true), 
            child: Text(isDanger ? "Delete" : "Confirm & Paid"),
          ),
        ],
      ),
    );
  }

  void _showStatusSheet() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Wrap(
        children: [
          ListTile(
            title: const Text('Pending'), 
            onTap: () { 
              _handleUpdateStatus('Pending'); 
              Navigator.pop(context); 
            },
          ),
          ListTile(
            title: const Text('Preparing'), 
            onTap: () { 
              _handleUpdateStatus('Preparing'); 
              Navigator.pop(context); 
            },
          ),
          ListTile(
            title: const Text('Served'), 
            onTap: () { 
              _handleUpdateStatus('Served'); 
              Navigator.pop(context); 
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF2F2F7),
      appBar: AppBar(
        title: const Text("Order Details", style: TextStyle(fontWeight: FontWeight.w600, color: Colors.black)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: Column(
        children: [
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Table ${_currentOrder.tableNo}", style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w700, letterSpacing: -0.5)),
                    Text("Order #${_currentOrder.id}", style: TextStyle(color: Colors.grey[600], fontSize: 16)),
                  ],
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(color: _currentOrder.backgroundColor.withOpacity(0.2), borderRadius: BorderRadius.circular(12)),
                  child: Text(_currentOrder.status.toUpperCase(), style: TextStyle(color: _currentOrder.statusColor, fontWeight: FontWeight.w700, fontSize: 12)),
                ),
              ],
            ),
          ),
          Expanded(
            child: FutureBuilder<List<Map<String, dynamic>>>(
              future: _itemsFuture,
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const Center(child: CircularProgressIndicator.adaptive());
                final items = snapshot.data!;
                return ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (_, i) => Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text("${items[i]['quantity']}x ${items[i]['name_snapshot']}", style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w500)),
                        Text("RM ${items[i]['price_snapshot']}", style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 40),
            decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(30))),
            child: Row(
              children: [
                IconButton(
                  onPressed: _currentOrder.canDelete ? () => _handleDeleteOrder() : null,
                  icon: Icon(Icons.delete_forever, color: _currentOrder.canDelete ? Colors.red : Colors.grey[400]),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: CupertinoButton(
                    color: _currentOrder.isPaid ? Colors.grey[300] : (_currentOrder.canProcessPayment ? const Color.fromARGB(255, 0, 0, 0) : Colors.black),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    borderRadius: BorderRadius.circular(16),
                    onPressed: _currentOrder.isPaid ? null : () => _currentOrder.canProcessPayment ? _handlePayment() : _showStatusSheet(),
                    child: Text(_currentOrder.isPaid ? "Paid" : (_currentOrder.canProcessPayment ? "Process Payment" : "Update Status"), 
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}