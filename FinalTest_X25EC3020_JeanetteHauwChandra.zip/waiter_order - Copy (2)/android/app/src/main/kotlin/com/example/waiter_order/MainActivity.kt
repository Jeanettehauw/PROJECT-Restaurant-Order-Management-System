package com.example.waiter_order

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
